package bitc.fullstack405.server_intravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerIntravelApplication {

  public static void main(String[] args) {
    SpringApplication.run(ServerIntravelApplication.class, args);
  }

}
