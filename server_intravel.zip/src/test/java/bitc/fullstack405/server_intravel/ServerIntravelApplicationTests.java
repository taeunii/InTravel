package bitc.fullstack405.server_intravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerIntravelApplicationTests {

  @Test
  void contextLoads() {
  }

}
